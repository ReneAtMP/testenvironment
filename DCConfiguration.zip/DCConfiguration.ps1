Configuration InstallADDSRole {
    param(
        [Parameter(Mandatory)]
        [String]$DomainName,
        [Parameter(Mandatory)]
        [String]$AdminPassword,
        [Parameter(Mandatory)]
        [String]$SafeModePassword
    )

    Import-DscResource -ModuleName PSDesiredStateConfiguration

    Node 'localhost' {
        WindowsFeature 'AD-Domain-Services' {
            Ensure = 'Present'
            Name   = 'AD-Domain-Services'
        }

        WindowsFeature 'RSAT-AD-Tools' {
            Ensure = 'Present'
            Name   = 'RSAT-AD-Tools'
        }
    }
}